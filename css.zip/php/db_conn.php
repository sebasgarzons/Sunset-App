<?php
  
  $host="localhost";
  $db="db_sunset";
  $user="adm_sunset";
  $pass="adm_sunset123";


  $walthr_date = $_POST["walthr_datephp"];
  $mov_date = $_POST["mov_datephp"];
  $cstm_name = $_POST["cstm_namephp"];
  $cntct = $_POST["cntctphp"];
  $phn = $_POST["phnphp"];
  $fx = $_POST["fxphp"];
  $ml = $_POST["mlphp"];
  $old_adrss = $_POST["old_adrssphp"];
  $old_ct = $_POST["old_ctphp"];
  $old_st = $_POST["old_stphp"];
  $old_zpcd = $_POST["old_zpcdphp"];
  $nw_adrss = $_POST["nw_adrssphp"];
  $nw_ct = $_POST["nw_ctphp"];
  $nw_st = $_POST["nw_stphp"];
  $nwz_pcd = $_POST["nwz_pcdphp"];
  $ml_ls = $_POST["ml_lsphp"];
  $id = $_POST["idphp"];

  $conn=mysqli_connect($host, $user, $pass, $db);

  if (!$conn){
    die ("Error al conectar".mysqli_connect_error());
  }else{
    
  }

  $SQL = "INSERT INTO info_user (wlktrgh_dt, mvng_dt, name, contact, phone, fax, mail,  old_adress, old_city, old_st, old_zipcode,  new_adress, new_city, new_st, new_zipcode, mail_ls, ID) values ('$walthr_date', '$mov_date', '$cstm_name', '$cntct', '$phn', '$fx', '$ml', '$old_adrss', '$old_ct', '$old_st', '$old_zpcd', '$nw_adrss', '$nw_ct', '$nw_st', '$nwz_pcd', '$ml_ls', '$id')";

  if (mysqli_query($conn,$SQL)){
    echo "Producto guardado éxitosamente";
  }else{
    echo "error".$SQL."<br>".mysqli_error($conn);
  }
  mysqli_close($conn);
?>